from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'respondent_level.csv'
RES = ROOT / 'results'
FIG = RES / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from scipy.stats import gaussian_kde
R = json.load(open(RES / 'results.json')); out = FIG
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.linewidth':0.6,'axes.edgecolor':'#555',
    'xtick.major.width':0.6,'ytick.major.width':0.6,'xtick.color':'#333','ytick.color':'#333','savefig.dpi':600})
def clean(ax):
    for s in ['top','right']: ax.spines[s].set_visible(False)
d = pd.read_csv(DATA); d['date'] = pd.to_datetime(d.date)
d['timing'] = np.where(d.date < '2026-06-11', 'Before', 'During/after'); d['qol_hi'] = (d.qol > 50).astype(int)
order = ['10–17','18–29','30–44','45–59','≥60']

# ---------- Figure 3 (landscape, panels A and B only) ----------
fig, ax = plt.subplots(1, 2, figsize=(10, 3.9), gridspec_kw={'wspace':0.18})
for k, (v, t) in enumerate([('family','A  Perceived contribution to family cohesion'), ('qol','B  Perceived contribution to quality of life')]):
    data = [d.loc[d.age_group == g, v] for g in order]
    ax[k].boxplot(data, widths=0.5, patch_artist=True, showfliers=False, medianprops=dict(color='#b2182b', lw=1.5),
                  boxprops=dict(facecolor='#dce7f0', edgecolor='#2166ac', lw=0.8), whiskerprops=dict(color='#2166ac', lw=0.8), capprops=dict(color='#2166ac', lw=0.8))
    rng = np.random.default_rng(1)
    for i, x in enumerate(data): ax[k].scatter(i + 1 + rng.uniform(-0.17, 0.17, len(x)), x, s=3.5, color='#555', alpha=0.35, lw=0)
    ax[k].set_xticks(range(1, 6)); ax[k].set_xticklabels([f'{g}\n(n={len(x)})' for g, x in zip(order, data)], fontsize=8)
    ax[k].set_ylim(-2, 104); ax[k].set_ylabel('Score (1–100)'); ax[k].set_xlabel('Age group (years)')
    ax[k].set_title(t, loc='left', fontsize=10, fontweight='bold'); clean(ax[k])
fig.savefig(f'{out}/Figure3.png', bbox_inches='tight'); fig.savefig(f'{out}/Figure3.pdf', bbox_inches='tight'); plt.close(fig)

# ---------- Figure 4 (curves) ----------
dm = d[d.region != 'Abroad'].copy()
m = smf.logit("qol_hi ~ family + C(age_group, Treatment('18–29')) + C(region, Treatment('Pichincha')) + C(timing)", data=dm).fit(disp=0)
fig, ax = plt.subplots(1, 2, figsize=(10.5, 4.2), gridspec_kw={'wspace':0.32})
a = ax[0]; x = np.linspace(1, 100, 200)
cols = {g: c for g, c in zip(order, ['#08306b', '#2171b5', '#6baed6', '#9ecae1', '#bdbdbd'])}
cross = {}
for g in order:
    nd = pd.DataFrame({'family': x, 'age_group': g, 'region': 'Pichincha', 'timing': 'During/after'})
    p = m.predict(nd).values; cross[g] = x[np.argmin(abs(p - 0.5))]
    a.plot(x, p, color=cols[g], lw=2.2 if g in ('10–17', '45–59') else 1.4, zorder=3 if g in ('10–17','45–59') else 2)
    a.text(101.5, p[-1], f'{g} y', va='center', fontsize=7.8, color=cols[g] if g!='≥60' else '#7f7f7f')
a.axhline(0.5, color='#999', lw=0.7, ls='--'); a.text(2, 0.515, 'Probability = 0.5', fontsize=7.5, color='#666')
a.set_clip_on(False)
a.annotate(f'Adolescents (10–17 y) reach 0.5\nat a score of ≈{cross["10–17"]:.0f}', xy=(cross['10–17'], 0.5), xytext=(12, 0.80),
           fontsize=8, color='#08306b', arrowprops=dict(arrowstyle='->', color='#08306b', lw=0.8))
a.annotate(f'Adults aged 45–59 y reach 0.5\nat a score of ≈{cross["45–59"]:.0f}', xy=(cross['45–59'], 0.5), xytext=(62, 0.15),
           fontsize=8, color='#2c5d8a', arrowprops=dict(arrowstyle='->', color='#2c5d8a', lw=0.8))
a.set_xlim(0, 100); a.set_ylim(0, 1); a.set_xticks(range(0,101,20)); a.set_xlabel('Perceived contribution to family cohesion (score 1–100)')
a.set_ylabel('Predicted probability of a high\nquality-of-life score (>50)')
a.text(101.5, 0.93, 'Age group', fontsize=7.8, fontweight='bold', color='#333')
a.set_title('A  Family cohesion and quality of life', loc='left', fontsize=10, fontweight='bold'); clean(a)

b = ax[1]; xs = np.linspace(0, 100, 400)
spec = [('Before', '#7f7f7f', 'Before the tournament\n(1–10 June; n = %d)'), ('During/after', '#2166ac', 'During or after the tournament\n(11 June–24 July; n = %d)')]
for t, c, lab in spec:
    v = d.loc[d.timing == t, 'family'].values; vr = np.concatenate([v, -v, 200 - v]); kde = gaussian_kde(vr, bw_method=0.12); y = kde(xs); y = y / y.max()
    b.plot(xs, y, color=c, lw=2.2, label=lab % len(v)); b.fill_between(xs, 0, y, color=c, alpha=0.08)
    med = np.median(v); b.axvline(med, color=c, lw=0.8, ls=':')
mb, md = d.loc[d.timing=='Before','family'].median(), d.loc[d.timing=='During/after','family'].median()
b.annotate(f'Median {mb:.0f}', xy=(mb, 1.0), xytext=(mb + 4, 1.06), fontsize=8, color='#555')
b.annotate(f'Median {md:.0f}', xy=(md, 1.0), xytext=(md - 22, 1.06), fontsize=8, color='#2166ac')
b.set_xlim(0, 100); b.set_ylim(0, 1.15); b.set_yticks([0, 0.5, 1]); b.set_xlabel('Perceived contribution to family cohesion (score 1–100)')
b.set_ylabel('Relative density (peak = 1)'); b.legend(frameon=False, fontsize=7.5, loc='upper left')
b.set_title('B  Family cohesion by response timing', loc='left', fontsize=10, fontweight='bold'); clean(b)
fig.savefig(f'{out}/Figure4.png', bbox_inches='tight'); fig.savefig(f'{out}/Figure4.pdf', bbox_inches='tight')
print(cross)
