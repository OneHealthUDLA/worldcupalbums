from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'respondent_level.csv'
RES = ROOT / 'results'
FIG = RES / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
import sys, json, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
import statsmodels.formula.api as smf
import scikit_posthocs as sp
sys.path.insert(0, str(Path(__file__).resolve().parent))
from importlib import import_module
A = import_module('aggregate_items')

d = pd.read_csv(DATA); outdir = RES
R = {}
def ci(k, n=621):
    lo, hi = proportion_confint(k, n, method='wilson'); return [100*k/n, 100*lo, 100*hi]
def mi(s): q = s.quantile([.25,.5,.75]); return [float(q[.5]), float(q[.25]), float(q[.75])]

# ---------- Respondent-level ----------
R['n'] = len(d)
R['age'] = {'median_iqr': mi(d.age), 'mean': d.age.mean(), 'sd': d.age.std(), 'min': int(d.age.min()), 'max': int(d.age.max())}
R['age_group'] = {k: [int(v), 100*v/len(d)] for k, v in d.age_group.value_counts().reindex(['10–17','18–29','30–44','45–59','≥60']).items()}
R['region'] = {k: [int(v), 100*v/len(d)] for k, v in d.region.value_counts().items()}
R['province'] = {k: [int(v), 100*v/len(d)] for k, v in d.province.value_counts().items()}
R['n_provinces_ecuador'] = int(d.loc[d.province!='Abroad','province'].nunique())
R['dates'] = [str(d.date.min()), str(d.date.max())]
dd = pd.to_datetime(d.date)
R['during_tournament'] = int(((dd >= '2026-06-11') & (dd <= '2026-07-19 23:59')).sum())
R['before_tournament'] = int((dd < '2026-06-11').sum()); R['after_tournament'] = int((dd > '2026-07-19 23:59').sum())

for v in ['family','qol']:
    s = d[v]
    R[v] = {'median_iqr': mi(s), 'mean': s.mean(), 'sd': s.std(),
            'pct_gt50': ci(int((s>50).sum())), 'pct_ge75': ci(int((s>=75).sum())),
            'pct_eq100': 100*(s==100).mean(), 'pct_le25': 100*(s<=25).mean()}
    for g in ['age_group','region']:
        sub = d if g=='age_group' else d[d.region!='Abroad']
        order = ['10–17','18–29','30–44','45–59','≥60'] if g=='age_group' else ['Pichincha','El Oro','Other provinces']
        grp = {k: {'n': int(len(x)), 'median_iqr': mi(x[v]), 'mean': x[v].mean(), 'sd': x[v].std()} for k, x in sub.groupby(g, observed=True)}
        H, p = stats.kruskal(*[sub.loc[sub[g]==k, v] for k in order])
        eps2 = (H - len(order) + 1) / (len(sub) - len(order))  # epsilon-squared (Tomczak & Tomczak)
        dunn = sp.posthoc_dunn(sub, val_col=v, group_col=g, p_adjust='holm')
        R[f'{v}_by_{g}'] = {'groups': {k: grp[k] for k in order}, 'H': H, 'p': p, 'eps2': eps2,
                            'dunn_holm': {f'{a} vs {b}': float(dunn.loc[a,b]) for i,a in enumerate(order) for b in order[i+1:]}}
    rho, p = stats.spearmanr(d.age, s); R[f'{v}_age_spearman'] = [rho, p]

rho, p = stats.spearmanr(d.family, d.qol); R['family_qol_spearman'] = [rho, p]
# bootstrap CI for rho
rng = np.random.default_rng(2026); bs = []
for _ in range(5000):
    i = rng.integers(0, len(d), len(d)); bs.append(stats.spearmanr(d.family.values[i], d.qol.values[i])[0])
R['family_qol_spearman_ci'] = list(np.percentile(bs, [2.5, 97.5]))

# Multivariable linear model: QoL ~ family cohesion + age group + region (HC3 robust SE)
dm = d[d.region!='Abroad'].copy()
dm['family10'] = dm.family/10
mod = smf.ols("qol ~ family10 + C(age_group, Treatment('18–29')) + C(region, Treatment('Pichincha'))", data=dm).fit(cov_type='HC3')
R['ols_qol'] = {'n': int(mod.nobs), 'r2': mod.rsquared, 'adj_r2': mod.rsquared_adj,
                'coef': {k: [mod.params[k], *mod.conf_int().loc[k].tolist(), mod.pvalues[k]] for k in mod.params.index}}
mod2 = smf.ols("family ~ C(age_group, Treatment('18–29')) + C(region, Treatment('Pichincha'))", data=dm).fit(cov_type='HC3')
R['ols_family'] = {'n': int(mod2.nobs), 'r2': mod2.rsquared,
                   'coef': {k: [mod2.params[k], *mod2.conf_int().loc[k].tolist(), mod2.pvalues[k]] for k in mod2.params.index}}
# Sensitivity: adults only, residents of Ecuador
ad = d[(d.age>=18) & (d.region!='Abroad')]
R['sens_adults'] = {'n': len(ad), 'family': mi(ad.family), 'qol': mi(ad.qol),
                    'rho': list(stats.spearmanr(ad.family, ad.qol))}

# ---------- Aggregated items ----------
agg = {}
for k, (lab, cats) in {**A.items, **A.multi}.items():
    agg[k] = {'label': lab, 'cats': {c: [n, *ci(n)] for c, n in cats}}
R['agg'] = agg
def likert(dic, labels, top_from):
    out = {}
    for k, (lab, f) in dic.items():
        f = np.array(f); sc = np.arange(1,6); m = (f*sc).sum()/f.sum(); sd = np.sqrt((f*(sc-m)**2).sum()/(f.sum()-1))
        cum_med = np.searchsorted(np.cumsum(f), (f.sum()+1)/2) + 1
        out[k] = {'label': lab, 'freq': f.tolist(), 'n_selections': int(f.sum()), 'pct': (100*f/621).tolist(), 'mean': m, 'sd': sd, 'median': int(cum_med),
                  'top': ci(int(f[top_from:].sum())), 'top2': ci(int(f[3:].sum())), 'none': ci(int(f[0]))}
    return out
R['benefit'] = likert(A.benefit, A.L5, 2)   # 'moderately' or more
# Q26 allowed multiple selections (644 selections/621 respondents): endorsed proportion bounded
ex = R['benefit']['Q26']['n_selections'] - 621
R['benefit']['Q26']['top_bounds'] = [100*(481-ex)/621, 100*481/621]; R['benefit']['Q26']['multi'] = True
R['harm_l'] = likert(A.harm_l, A.L5, 2)
R['harm_f'] = likert(A.harm_f, A.F5, 2)     # 'sometimes' or more
R['consent'] = A.consent
R['age_n_minors'] = int((d.age<18).sum()); R['age_n_lt14'] = int((d.age<14).sum())

# derived aggregated summaries
R['money_gt100'] = ci(122+102+15+2); R['money_lt50'] = ci(109+109)
R['hours_ge3'] = ci(149+24+6); R['screen_ge1'] = ci(216+160+39+7); R['screen_ge3'] = ci(160+39+7)
R['again_yes'] = ci(233+188); R['again_no'] = ci(47+61)
R['for_family_children'] = ci(17+111+119)
R['with_family'] = ci(136+75+204)
R['swap_main'] = ci(69+106+135+12+12)
R['edu_higher'] = ci(289+125)

json.dump(R, open(f'{outdir}/results.json','w'), indent=1, ensure_ascii=False, default=float)
print(json.dumps({k: R[k] for k in ['age','family','qol','family_qol_spearman','family_qol_spearman_ci','sens_adults','dates','during_tournament','before_tournament','after_tournament','n_provinces_ecuador']}, indent=1, ensure_ascii=False, default=float))
for v in ['family','qol']:
    for g in ['age_group','region']: print(v,g, json.dumps(R[f'{v}_by_{g}'], ensure_ascii=False, default=float))
    print(v,'age rho', R[f'{v}_age_spearman'])
print(mod.summary()); print(mod2.summary())
for s in ['benefit','harm_l','harm_f']:
    for k,v in R[s].items(): print(k, v['label'], 'mean %.2f sd %.2f med %d top %.1f (%.1f-%.1f) top2 %.1f none %.1f' % (v['mean'],v['sd'],v['median'],*v['top'],v['top2'][0],v['none'][0]))
