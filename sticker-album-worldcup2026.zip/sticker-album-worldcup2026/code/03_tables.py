from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'respondent_level.csv'
RES = ROOT / 'results'
FIG = RES / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
(RES / 'tables').mkdir(exist_ok=True)
import json
R = json.load(open(RES / 'results.json'))
f1 = lambda x: f'{x:.1f}'
def row(lab, n, p): return f'| {lab} | {n} ({p:.1f}) |'
L = ['### Table 1. Characteristics of respondents and collecting practices (n = 621)', '', '| Characteristic | n (%) |', '| --- | --- |']
a = R['age']; L.append(f"| Age, years, median (IQR) | {a['median_iqr'][0]:.0f} ({a['median_iqr'][1]:.0f}–{a['median_iqr'][2]:.0f}) |")
L.append('| **Age group, years** | |')
for k,(n,p) in R['age_group'].items(): L.append(row(' '+k, n, p))
def block(title, key, rename=None):
    L.append(f'| **{title}** | |')
    for c,(n,p,lo,hi) in R['agg'][key]['cats'].items(): L.append(row(' '+(rename or {}).get(c,c), n, p))
block('Sex','Q4_sex'); block('Highest educational level','Q7_edu')
L.append('| **Region of residence** | |')
for k in ['Pichincha','El Oro','Other provinces','Abroad']: n,p = R['region'][k]; L.append(row(' '+k, n, p))
block('Currently collecting','Q2_current'); block('Collected albums before','Q8_prev')
block('Main beneficiary of the collection','Q10_for'); block('Main companions in the activity','Q11_with')
block('Main source of stickers','Q12_obtain'); block('Preferred swapping modalityᵃ','Q13_mode')
block('Weekly time devoted to collecting','Q14_hours')
block('Total expenditure, US$ᵇ','Q15_money',{'<20':'<20','20–50':'20–50','50–80':'50–80','80–100':'80–100','>100':'>100','>200':'>200','>500':'>500','>1000':'>1000'})
block('Perceived weekly reduction in screen time','Q16_screen'); block('Would collect again','Q27_again')
L += ['', 'IQR = interquartile range. ᵃMultiple response; percentages do not sum to 100. ᵇResponse categories as worded in the questionnaire; categories above US$100 were not mutually exclusive.', '']

L += ['### Table 2. Perceived benefits and adverse experiences of sticker-album collecting (n = 621)', '',
      '| Domain | Not at all / Never, % | A little / Rarely, % | Moderately / Sometimes, % | Quite a lot / Often, % | Very much / Always, % | Mean (SD)ᵃ | Endorsedᵇ, % (95% CI) |',
      '| --- | --- | --- | --- | --- | --- | --- | --- |', '| **Perceived benefits** | | | | | | | |']
def lik(sec):
    for k,v in sorted(R[sec].items(), key=lambda kv: -kv[1]['top'][0]):
        p = v['pct']; t = v['top']
        if v.get('multi'):
            b = v['top_bounds']; L.append(f"| {v['label']}\u1d9c | {p[0]:.1f} | {p[1]:.1f} | {p[2]:.1f} | {p[3]:.1f} | {p[4]:.1f} | — | {b[0]:.1f}–{b[1]:.1f}\u1d9c |"); continue
        L.append(f"| {v['label']} | {p[0]:.1f} | {p[1]:.1f} | {p[2]:.1f} | {p[3]:.1f} | {p[4]:.1f} | {v['mean']:.2f} ({v['sd']:.2f}) | {t[0]:.1f} ({t[1]:.1f}–{t[2]:.1f}) |")
lik('benefit'); L.append('| **Adverse experiences (frequency)** | | | | | | | |'); lik('harm_f')
L.append('| **Adverse experiences (intensity)** | | | | | | | |'); lik('harm_l')
L += ['', 'ᵃItems scored 1–5. ᵇAt least “moderately” for benefit and intensity items; at least “sometimes” for frequency items. CI = Wilson score interval. \u1d9cThis item allowed more than one response (644 selections from 621 respondents); percentages are of respondents and do not sum to 100, and the endorsed proportion is reported as its lower–upper bound.', '']

L += ['### Table 3. Perceived contribution of collecting to family cohesion and quality of life (scores 1–100)', '',
      '| Group | n | Family cohesion, median (IQR) | Quality of life, median (IQR) |', '| --- | --- | --- | --- |']
F, Q = R['family'], R['qol']; mi = lambda m: f'{m[0]:.0f} ({m[1]:.0f}–{m[2]:.0f})'.replace('.0','')
fm = lambda m: '%s (%s–%s)' % tuple(('%.1f' % x).replace('.0','') if round(x,1)!=int(x) else str(int(x)) for x in m)
L.append(f"| All respondents | 621 | {fm(F['median_iqr'])} | {fm(Q['median_iqr'])} |")
for g,lab,P in [('age_group','Age group, years',None),('region','Region of residenceᵃ',None)]:
    fa, qa = R[f'family_by_{g}'], R[f'qol_by_{g}']
    L.append(f"| **{lab}** | | P = {fa['p']:.2f}ᵇ | P = {qa['p']:.2f}ᵇ |")
    for k in fa['groups']:
        L.append(f"|  {k} | {fa['groups'][k]['n']} | {fm(fa['groups'][k]['median_iqr'])} | {fm(qa['groups'][k]['median_iqr'])} |")
L += ['', 'ᵃResidents of Ecuador (n = 613). ᵇKruskal–Wallis test. Spearman correlation between the two scores: ρ = %.2f (bootstrap 95%% CI %.2f–%.2f).' % (R['family_qol_spearman'][0], *R['family_qol_spearman_ci']), '']
open(RES / 'tables' / 'tables.md','w').write('\n'.join(L)); print('\n'.join(L))
