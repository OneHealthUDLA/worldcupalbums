# Aggregated (SurveyMonkey summary) items, transcribed verbatim from the summary export; n=621 for every item.
N = 621
items = {
 'Q2_current': ('Currently collecting football sticker albums', [('Yes',477),('No',144)]),
 'Q4_sex': ('Sex', [('Female',269),('Male',352)]),
 'Q7_edu': ('Highest educational level', [('Primary',29),('Secondary',134),('Technical/technological',44),('University',289),('Postgraduate',125)]),
 'Q8_prev': ('Previously collected football sticker albums', [('Yes',453),('No',168)]),
 'Q9_wc': ('Most recent/other World Cup album collected (single response)', [('Qatar 2022',209),('Russia 2018',44),('Brazil 2014',92),('South Africa 2010',54),('USA–Canada–Mexico 2026',92),('None',130)]),
 'Q10_for': ('Main beneficiary of the collection', [('Self',270),('Grandchildren',17),('Children',111),('Whole family',119),('Partner',41),('Other',63)]),
 'Q11_with': ('Main companions in the activity', [('Alone',98),('Children',136),('Partner',75),('Other relatives',204),('Friends',55),('Other collectors',9),('Social-media/WhatsApp groups',1),('Other',43)]),
 'Q12_obtain': ('Main source of stickers', [('Buying new packets',260),('Swapping with relatives',69),('Swapping with friends',106),('Swapping at malls, parks, shops or swap events',135),('Swapping via social media/WhatsApp',12),('Digital platforms/apps',12),('Buying specific missing stickers',27)]),
 'Q14_hours': ('Weekly time spent collecting, sorting or swapping', [('<1 h',197),('1–2 h',245),('3–5 h',149),('6–10 h',24),('>10 h',6)]),
 'Q15_money': ('Total expenditure (US$)', [('<20',109),('20–50',109),('50–80',71),('80–100',91),('>100',122),('>200',102),('>500',15),('>1000',2)]),
 'Q16_screen': ('Self-perceived weekly reduction in screen time', [('0 h',84),('<1 h',115),('1–2 h',216),('3–5 h',160),('6–10 h',39),('>10 h',7)]),
 'Q27_again': ('Would collect again in the future', [('Definitely not',47),('Probably not',61),('Not sure',92),('Probably yes',233),('Definitely yes',188)]),
}
multi = {  # multiple-response items (percent of respondents)
 'Q13_mode': ('Preferred swapping modality (multiple response)', [('Does not swap',83),('In person with family/friends',445),('In person with strangers',216),('Social media/WhatsApp',77),('Digital platforms/apps',38),('Combined in-person and digital',77)]),
 'Q28_neg': ('Other negative experiences (multiple response)', [('None',353),('Theft or fraud',62),('Excessive time devoted',107),('Conflicts with strangers/other collectors',92),('Other',50)]),
}
L5 = ['Not at all','A little','Moderately','Quite a lot','Very much']
F5 = ['Never','Rarely','Sometimes','Often','Always']
benefit = {
 'Q19':('Organisational skills', [90,118,190,155,68]),
 'Q20':('Negotiation skills', [77,83,216,171,74]),
 'Q21':('Socialisation', [58,76,190,191,106]),
 'Q22':('Emotional well-being/recreation (swapping)', [57,90,219,164,91]),
 'Q24':('Disconnection from daily worries', [77,115,214,145,70]),
 'Q25':('Personal goal and sense of achievement', [70,97,231,144,79]),
 'Q26':('Learning something new', [72,91,225,172,84]),
}
harm_l = {
 'Q23':('Anxiety or worry', [244,178,161,33,5]),
 'Q34':('Concern about gambling-like dynamics for children', [278,166,108,48,21]),
}
harm_f = {
 'Q29':('Spent more money than planned', [143,156,179,99,44]),
 'Q30':('Unsuccessful attempts to cut down purchasing', [249,140,136,66,30]),
 'Q31':('Household financial strain', [380,129,81,18,13]),
 'Q32':('Arguments with family or partner', [400,123,67,24,7]),
 'Q33':('Neglected responsibilities (work, study, home, sleep)', [405,98,77,29,12]),
 'Q35':('Frustration over duplicates/missing stickers', [206,149,130,103,33]),
}
consent = [('Accepted',618),('Declined',3)]
