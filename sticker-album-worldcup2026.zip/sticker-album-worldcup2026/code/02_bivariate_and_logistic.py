from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'respondent_level.csv'
RES = ROOT / 'results'
FIG = RES / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
import json, numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
d = pd.read_csv(DATA); d['date'] = pd.to_datetime(d.date)
d['timing'] = np.where(d.date < '2026-06-11', 'Before', 'During/after')
d['minor'] = np.where(d.age < 18, '10–17', '≥18')
d['fam_hi'] = (d.family > 50).astype(int); d['qol_hi'] = (d.qol > 50).astype(int)
R = {}
def mw(var, g):
    a, b = [d.loc[d[g]==k, var] for k in sorted(d[g].unique())]
    U, p = stats.mannwhitneyu(a, b); r_rb = 1 - 2*U/(len(a)*len(b))
    return {'groups': {k: [int((d[g]==k).sum()), *d.loc[d[g]==k, var].quantile([.5,.25,.75]).tolist()] for k in sorted(d[g].unique())}, 'U': U, 'p': p, 'rank_biserial': r_rb}
for v in ['family','qol']:
    R[f'{v}_timing'] = mw(v, 'timing'); R[f'{v}_minor'] = mw(v, 'minor')
# chi-square of high scores (>50) by age group and region
dr = d[d.region!='Abroad']
for v in ['fam_hi','qol_hi']:
    for g, dd in [('age_group', d), ('region', dr), ('timing', d)]:
        ct = pd.crosstab(dd[g], dd[v]); chi, p, dof, _ = stats.chi2_contingency(ct)
        R[f'{v}_by_{g}'] = {'table': {k: [int(ct.loc[k,1]), int(ct.loc[k].sum()), 100*ct.loc[k,1]/ct.loc[k].sum()] for k in ct.index}, 'chi2': chi, 'dof': dof, 'p': p}
    # trend across ordered age groups
    tau, p = stats.kendalltau(d.age_group.map({'10–17':1,'18–29':2,'30–44':3,'45–59':4,'≥60':5}), d[v]); R[f'{v}_age_trend'] = [tau, p]
# logistic models: high QoL ~ high family cohesion + age group + region + timing ; high family ~ age + region + timing
dm = dr.copy()
def logit(f):
    m = smf.logit(f, data=dm).fit(disp=0); ci = m.conf_int()
    return {'n': int(m.nobs), 'pseudo_r2': m.prsquared, 'or': {k: [float(np.exp(m.params[k])), float(np.exp(ci.loc[k,0])), float(np.exp(ci.loc[k,1])), float(m.pvalues[k])] for k in m.params.index if k!='Intercept'}}
R['logit_qol'] = logit("qol_hi ~ fam_hi + C(age_group, Treatment('18–29')) + C(region, Treatment('Pichincha')) + C(timing)")
R['logit_fam'] = logit("fam_hi ~ C(age_group, Treatment('18–29')) + C(region, Treatment('Pichincha')) + C(timing)")
# crude OR high QoL by high family
ct = pd.crosstab(d.fam_hi, d.qol_hi); a,b,c,dd_ = ct.loc[1,1], ct.loc[1,0], ct.loc[0,1], ct.loc[0,0]
orr = a*dd_/(b*c); se = np.sqrt(1/a+1/b+1/c+1/dd_)
R['crude_or_qol_fam'] = [orr, orr*np.exp(-1.96*se), orr*np.exp(1.96*se), stats.chi2_contingency(ct)[1], int(a), int(a+b), int(c), int(c+dd_)]
json.dump(R, open(RES / 'bivariate.json','w'), indent=1, ensure_ascii=False, default=float)
for k, v in R.items(): print(k, json.dumps(v, ensure_ascii=False, default=lambda x: round(float(x),4)))
