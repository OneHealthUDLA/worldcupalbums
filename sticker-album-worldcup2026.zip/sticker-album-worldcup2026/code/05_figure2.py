from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'respondent_level.csv'
RES = ROOT / 'results'
FIG = RES / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
import json, sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R = json.load(open(RES / 'results.json')); d = pd.read_csv(DATA); out = FIG
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.linewidth':0.6,'axes.edgecolor':'#555',
    'xtick.major.width':0.6,'ytick.major.width':0.6,'xtick.color':'#333','ytick.color':'#333','axes.labelcolor':'#222',
    'savefig.dpi':600,'figure.facecolor':'white'})
DIV = ['#b2182b','#ef8a62','#d9d9d6','#67a9cf','#2166ac']   # neg -> neutral -> pos

def diverging(ax, items, cats, title, reverse_good=False):
    labels = [v['label'] + ('*' if v.get('multi') else '') for v in items]; P = np.array([[100*x/sum(v['freq']) for x in v['freq']] for v in items])
    cols = DIV[::-1] if reverse_good else DIV
    order = np.argsort([p[3]+p[4]+p[2]/2 for p in P]) if not reverse_good else np.argsort([-(p[0]+p[1]/2) for p in P])
    P = P[order]; labels = [labels[i] for i in order]
    y = np.arange(len(labels))
    left = -(P[:,0]+P[:,1]+P[:,2]/2)
    for j in range(5):
        ax.barh(y, P[:,j], left=left, color=cols[j], height=0.68, edgecolor='white', linewidth=0.8, label=cats[j])
        for yi,(l,w) in enumerate(zip(left,P[:,j])):
            if w >= 7: ax.text(l+w/2, yi, f'{w:.0f}', ha='center', va='center', fontsize=7, color='white' if j in (0,4) else '#222')
        left = left + P[:,j]
    ax.axvline(0, color='#444', lw=0.6); ax.set_yticks(y); ax.set_yticklabels(labels)
    ax.set_xlim(-100,100); ax.set_xticks(range(-100,101,25)); ax.set_xticklabels([f'{abs(t)}' for t in range(-100,101,25)])
    ax.set_xlabel('Respondents (%)'); ax.set_title(title, loc='left', fontsize=9.5, fontweight='bold', pad=24)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    ax.legend(ncol=5, loc='lower center', bbox_to_anchor=(0.4,1.0), frameon=False, fontsize=7.5, handlelength=1.2, columnspacing=1)

L5 = ['Not at all','A little','Moderately','Quite a lot','Very much']; F5 = ['Never','Rarely','Sometimes','Often','Always']
fig, axes = plt.subplots(3,1, figsize=(7.2,8.6), gridspec_kw={'height_ratios':[7,6,2.2],'hspace':0.95})
diverging(axes[0], list(R['benefit'].values()), L5, 'A  Perceived benefits')
diverging(axes[1], list(R['harm_f'].values()), F5, 'B  Perceived adverse experiences (frequency)', reverse_good=True)
diverging(axes[2], list(R['harm_l'].values()), L5, 'C  Perceived adverse experiences (intensity)', reverse_good=True)
fig.savefig(f'{out}/Figure2.png', bbox_inches='tight'); fig.savefig(f'{out}/Figure2.pdf', bbox_inches='tight')

