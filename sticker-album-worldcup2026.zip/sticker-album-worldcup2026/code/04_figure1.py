from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'respondent_level.csv'
RES = ROOT / 'results'
FIG = RES / 'figures'
FIG.mkdir(parents=True, exist_ok=True)
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R = json.load(open(RES / 'results.json')); B = json.load(open(RES / 'bivariate.json')); out = FIG
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.linewidth':0.6,'axes.edgecolor':'#555',
    'xtick.major.width':0.6,'ytick.major.width':0.6,'xtick.color':'#333','ytick.color':'#333','savefig.dpi':600})
BLUE = '#2166ac'
def clean(ax):
    for s in ['top','right']: ax.spines[s].set_visible(False)

# ---------- Figure 3: intensity of engagement ----------
panels = [('Q14_hours','A  Weekly time devoted to collecting','Hours per week'),
          ('Q15_money','B  Total expenditure','US$'),
          ('Q16_screen','C  Perceived reduction in screen time','Hours per week'),
          ('Q27_again','D  Would collect again','')]
fig, axes = plt.subplots(2, 2, figsize=(7.4, 5.6), gridspec_kw={'hspace':0.75,'wspace':0.35})
for ax, (k, title, xl) in zip(axes.flat, panels):
    cats = R['agg'][k]['cats']; labs = list(cats); pct = [cats[c][1] for c in labs]; lo = [cats[c][2] for c in labs]; hi = [cats[c][3] for c in labs]
    n = len(labs); shades = np.linspace(0.35, 1, n)
    x = np.arange(n)
    for i in range(n):
        ax.bar(x[i], pct[i], width=0.68, color=BLUE, alpha=shades[i], edgecolor='white', linewidth=0.6)
        ax.errorbar(x[i], pct[i], yerr=[[pct[i]-lo[i]], [hi[i]-pct[i]]], color='#333', lw=0.7, capsize=2)
        ax.text(x[i], hi[i] + 1.2, f'{pct[i]:.1f}', ha='center', va='bottom', fontsize=7, color='#222')
    lab = [l.replace(' ', '\n', 1) if k == 'Q27_again' else l for l in labs]
    if k == 'Q15_money': lab = ['<20','20–50','50–80','80–100','>100*','>200*','>500*','>1000*']
    ax.set_xticks(x); ax.set_xticklabels(lab, fontsize=7, rotation=40 if k=='Q15_money' else 0, ha='right' if k=='Q15_money' else 'center')
    ax.set_ylim(0, max(hi) + 9); ax.set_ylabel('Respondents (%)'); ax.set_xlabel(xl)
    ax.set_title(title, loc='left', fontsize=9.5, fontweight='bold'); clean(ax)
fig.savefig(f'{out}/Figure1.png', bbox_inches='tight'); fig.savefig(f'{out}/Figure1.pdf', bbox_inches='tight'); plt.close(fig)

