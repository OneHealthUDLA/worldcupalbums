# Data dictionary

## `respondent_level.csv` (n = 621; one row per respondent)

| Variable | Type | Description |
|---|---|---|
| `id` | string | Study identifier (P001–P621), assigned in order of response. It does not correspond to the original SurveyMonkey respondent ID. |
| `date` | date (YYYY-MM-DD) | Date the response was submitted. Time of day was removed. |
| `response_period` | category | Timing relative to the 2026 FIFA World Cup (11 June–19 July 2026): `before`, `during` or `after`. |
| `age` | integer | Self-reported age in years (open response). |
| `age_group` | category | 10–17, 18–29, 30–44, 45–59, ≥60 years. |
| `province` | category | Province of residence, harmonised from free-text entries to the 24 Ecuadorian provinces; `Abroad` for residence outside Ecuador. |
| `region` | category | Pichincha, El Oro, Other provinces or Abroad. |
| `family` | integer (1–100) | Perceived contribution of collecting to family cohesion (1 = does not foster family cohesion at all; 100 = fosters it greatly). |
| `qol` | integer (1–100) | Perceived contribution of collecting to the respondent's quality of life (1 = not at all; 100 = very much). |

There are no missing values.

## `aggregated_items.csv` (closed questions; aggregate frequencies only)

| Variable | Description |
|---|---|
| `question` | Questionnaire item number (Q1–Q35). |
| `item` | Short English label of the item. |
| `response_type` | `single` or `multiple` response. Percentages of multiple-response items do not sum to 100. |
| `category` | Response option (translated to English). |
| `n` | Number of respondents who selected the option. |
| `pct_of_respondents` | `n` / 621 × 100. |

Item groups:
- **Q19–Q22, Q24–Q26:** perceived benefits (Not at all – Very much). Q26 accepted more than one response (644 selections).
- **Q29–Q33, Q35:** adverse experiences, frequency (Never – Always).
- **Q23, Q34:** adverse experiences, intensity (Not at all – Very much).
- **Q15 (expenditure):** the categories above US$100 were worded in the questionnaire as non-mutually exclusive thresholds (">100", ">200", ">500", ">1000") and are reported as recorded.

## Notes
- Closed items were exported from SurveyMonkey only as aggregate frequencies, so they cannot be linked to the respondent-level variables.
- Three respondents declined consent (Q1) but completed the questionnaire. They cannot be identified in the aggregate data and are included in both files.
