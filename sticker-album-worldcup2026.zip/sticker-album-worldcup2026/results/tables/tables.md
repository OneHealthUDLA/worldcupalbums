### Table 1. Characteristics of respondents and collecting practices (n = 621)

| Characteristic | n (%) |
| --- | --- |
| Age, years, median (IQR) | 28 (21–41) |
| **Age group, years** | |
|  10–17 | 64 (10.3) |
|  18–29 | 259 (41.7) |
|  30–44 | 178 (28.7) |
|  45–59 | 84 (13.5) |
|  ≥60 | 36 (5.8) |
| **Sex** | |
|  Female | 269 (43.3) |
|  Male | 352 (56.7) |
| **Highest educational level** | |
|  Primary | 29 (4.7) |
|  Secondary | 134 (21.6) |
|  Technical/technological | 44 (7.1) |
|  University | 289 (46.5) |
|  Postgraduate | 125 (20.1) |
| **Region of residence** | |
|  Pichincha | 392 (63.1) |
|  El Oro | 88 (14.2) |
|  Other provinces | 133 (21.4) |
|  Abroad | 8 (1.3) |
| **Currently collecting** | |
|  Yes | 477 (76.8) |
|  No | 144 (23.2) |
| **Collected albums before** | |
|  Yes | 453 (72.9) |
|  No | 168 (27.1) |
| **Main beneficiary of the collection** | |
|  Self | 270 (43.5) |
|  Grandchildren | 17 (2.7) |
|  Children | 111 (17.9) |
|  Whole family | 119 (19.2) |
|  Partner | 41 (6.6) |
|  Other | 63 (10.1) |
| **Main companions in the activity** | |
|  Alone | 98 (15.8) |
|  Children | 136 (21.9) |
|  Partner | 75 (12.1) |
|  Other relatives | 204 (32.9) |
|  Friends | 55 (8.9) |
|  Other collectors | 9 (1.4) |
|  Social-media/WhatsApp groups | 1 (0.2) |
|  Other | 43 (6.9) |
| **Main source of stickers** | |
|  Buying new packets | 260 (41.9) |
|  Swapping with relatives | 69 (11.1) |
|  Swapping with friends | 106 (17.1) |
|  Swapping at malls, parks, shops or swap events | 135 (21.7) |
|  Swapping via social media/WhatsApp | 12 (1.9) |
|  Digital platforms/apps | 12 (1.9) |
|  Buying specific missing stickers | 27 (4.3) |
| **Preferred swapping modalityᵃ** | |
|  Does not swap | 83 (13.4) |
|  In person with family/friends | 445 (71.7) |
|  In person with strangers | 216 (34.8) |
|  Social media/WhatsApp | 77 (12.4) |
|  Digital platforms/apps | 38 (6.1) |
|  Combined in-person and digital | 77 (12.4) |
| **Weekly time devoted to collecting** | |
|  <1 h | 197 (31.7) |
|  1–2 h | 245 (39.5) |
|  3–5 h | 149 (24.0) |
|  6–10 h | 24 (3.9) |
|  >10 h | 6 (1.0) |
| **Total expenditure, US$ᵇ** | |
|  <20 | 109 (17.6) |
|  20–50 | 109 (17.6) |
|  50–80 | 71 (11.4) |
|  80–100 | 91 (14.7) |
|  >100 | 122 (19.6) |
|  >200 | 102 (16.4) |
|  >500 | 15 (2.4) |
|  >1000 | 2 (0.3) |
| **Perceived weekly reduction in screen time** | |
|  0 h | 84 (13.5) |
|  <1 h | 115 (18.5) |
|  1–2 h | 216 (34.8) |
|  3–5 h | 160 (25.8) |
|  6–10 h | 39 (6.3) |
|  >10 h | 7 (1.1) |
| **Would collect again** | |
|  Definitely not | 47 (7.6) |
|  Probably not | 61 (9.8) |
|  Not sure | 92 (14.8) |
|  Probably yes | 233 (37.5) |
|  Definitely yes | 188 (30.3) |

IQR = interquartile range. ᵃMultiple response; percentages do not sum to 100. ᵇResponse categories as worded in the questionnaire; categories above US$100 were not mutually exclusive.

### Table 2. Perceived benefits and adverse experiences of sticker-album collecting (n = 621)

| Domain | Not at all / Never, % | A little / Rarely, % | Moderately / Sometimes, % | Quite a lot / Often, % | Very much / Always, % | Mean (SD)ᵃ | Endorsedᵇ, % (95% CI) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Perceived benefits** | | | | | | | |
| Socialisation | 9.3 | 12.2 | 30.6 | 30.8 | 17.1 | 3.34 (1.17) | 78.4 (75.0–81.5) |
| Learning something newᶜ | 11.6 | 14.7 | 36.2 | 27.7 | 13.5 | — | 73.8–77.5ᶜ |
| Emotional well-being/recreation (swapping) | 9.2 | 14.5 | 35.3 | 26.4 | 14.7 | 3.23 (1.15) | 76.3 (72.8–79.5) |
| Negotiation skills | 12.4 | 13.4 | 34.8 | 27.5 | 11.9 | 3.13 (1.17) | 74.2 (70.7–77.5) |
| Personal goal and sense of achievement | 11.3 | 15.6 | 37.2 | 23.2 | 12.7 | 3.10 (1.16) | 73.1 (69.5–76.4) |
| Disconnection from daily worries | 12.4 | 18.5 | 34.5 | 23.3 | 11.3 | 3.03 (1.17) | 69.1 (65.3–72.6) |
| Organisational skills | 14.5 | 19.0 | 30.6 | 25.0 | 11.0 | 2.99 (1.21) | 66.5 (62.7–70.1) |
| **Adverse experiences (frequency)** | | | | | | | |
| Spent more money than planned | 23.0 | 25.1 | 28.8 | 15.9 | 7.1 | 2.59 (1.20) | 51.9 (47.9–55.8) |
| Frustration over duplicates/missing stickers | 33.2 | 24.0 | 20.9 | 16.6 | 5.3 | 2.37 (1.24) | 42.8 (39.0–46.8) |
| Unsuccessful attempts to cut down purchasing | 40.1 | 22.5 | 21.9 | 10.6 | 4.8 | 2.18 (1.20) | 37.4 (33.6–41.2) |
| Neglected responsibilities (work, study, home, sleep) | 65.2 | 15.8 | 12.4 | 4.7 | 1.9 | 1.62 (1.00) | 19.0 (16.1–22.3) |
| Household financial strain | 61.2 | 20.8 | 13.0 | 2.9 | 2.1 | 1.64 (0.96) | 18.0 (15.2–21.3) |
| Arguments with family or partner | 64.4 | 19.8 | 10.8 | 3.9 | 1.1 | 1.57 (0.91) | 15.8 (13.1–18.9) |
| **Adverse experiences (intensity)** | | | | | | | |
| Anxiety or worry | 39.3 | 28.7 | 25.9 | 5.3 | 0.8 | 2.00 (0.97) | 32.0 (28.5–35.8) |
| Concern about gambling-like dynamics for children | 44.8 | 26.7 | 17.4 | 7.7 | 3.4 | 1.98 (1.11) | 28.5 (25.1–32.2) |

ᵃItems scored 1–5. ᵇAt least “moderately” for benefit and intensity items; at least “sometimes” for frequency items. CI = Wilson score interval. ᶜThis item allowed more than one response (644 selections from 621 respondents); percentages are of respondents and do not sum to 100, and the endorsed proportion is reported as its lower–upper bound.

### Table 3. Perceived contribution of collecting to family cohesion and quality of life (scores 1–100)

| Group | n | Family cohesion, median (IQR) | Quality of life, median (IQR) |
| --- | --- | --- | --- |
| All respondents | 621 | 75 (50–90) | 50 (20–75) |
| **Age group, years** | | P = 0.24ᵇ | P = 0.11ᵇ |
|  10–17 | 64 | 76.5 (60–95) | 60 (47.5–70.8) |
|  18–29 | 259 | 75 (50–90) | 50 (20–75.5) |
|  30–44 | 178 | 80 (50–95) | 50 (20–80) |
|  45–59 | 84 | 75 (50–80) | 50 (10–70) |
|  ≥60 | 36 | 65 (47.5–90) | 50 (10–90) |
| **Region of residenceᵃ** | | P = 0.06ᵇ | P = 0.21ᵇ |
|  Pichincha | 392 | 80 (50–90) | 50 (20–74.2) |
|  El Oro | 88 | 80 (43.8–97.2) | 50 (25–90) |
|  Other provinces | 133 | 70 (50–80) | 50 (20–70) |

ᵃResidents of Ecuador (n = 613). ᵇKruskal–Wallis test. Spearman correlation between the two scores: ρ = 0.61 (bootstrap 95% CI 0.55–0.66).
