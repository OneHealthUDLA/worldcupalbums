#!/usr/bin/env bash
# Reproduces all results, tables and figures from the files in data/
set -euo pipefail
cd "$(dirname "$0")"
for s in 01_descriptive_analysis 02_bivariate_and_logistic 03_tables 04_figure1 05_figure2 06_figures3_4; do
  echo "Running $s.py"; python code/$s.py > /dev/null
done
echo "Done. Outputs are in results/"
